<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class AN_ajax_koneksi_test extends CI_Controller{

	function test(){
		echo "ok";
	}

}