<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:33:59 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-05-09 16:34:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:34:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-component/media
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:37:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:39:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:53 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 16:40:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:40:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:41:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:42:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:44:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:44:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:44:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:44:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:44:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 81
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 82
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 83
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 81
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 82
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 83
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 81
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 82
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 83
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 81
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 82
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 83
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 81
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 82
ERROR - 2019-05-09 16:45:33 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 83
ERROR - 2019-05-09 16:45:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:45:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:46:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:46:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:46:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:46:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:46:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:47:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:49:08 --> Query error: Unknown column 'tahun' in 'field list' - Invalid query: SELECT `tahun`
FROM `infrastruktur`
GROUP BY `tahun`
ERROR - 2019-05-09 16:50:29 --> Severity: Notice --> Undefined variable: cge C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 16:50:29 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 50
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 51
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 52
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$progres C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 53
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$ppk C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 54
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_pelaksana C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 55
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 50
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 51
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 52
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$progres C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 53
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$ppk C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 54
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_pelaksana C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 55
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 50
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 51
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 52
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$progres C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 53
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$ppk C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 54
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_pelaksana C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 55
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 50
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 51
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 52
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$progres C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 53
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$ppk C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 54
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_pelaksana C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 55
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_kegiatan C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 50
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$anggaran C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 51
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nilai_kontrak C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 52
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$progres C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 53
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$ppk C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 54
ERROR - 2019-05-09 16:50:48 --> Severity: Notice --> Undefined property: stdClass::$nama_pelaksana C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 55
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:51:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:52:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:54:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:55:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:57:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:58:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 16:59:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:00:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:01:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:02:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:03:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:04:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:05:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> Undefined variable: sumd C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 45
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:49 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 46
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:06:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\pubmsumsel\application\views\ando\data_infrastruktur.php 47
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:14:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:15:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:19:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:20:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:21:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:21:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:23:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:23:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:24:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:24:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:24:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:24:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:24:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:25:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:26:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:26:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:27:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:28:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:28:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:28:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:29:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:29:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:29:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:29:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:04 --> Severity: Notice --> Undefined variable: tampung C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 784
ERROR - 2019-05-09 17:35:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:27 --> Severity: Notice --> Undefined variable: tampung C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 784
ERROR - 2019-05-09 17:35:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:36:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:36:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:36:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:39:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:41:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:42:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:45:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:47:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:47:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:47:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:47:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:47:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:48:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:48:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:48:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:48:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:48:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:50:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:52:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:52:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:52:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:52:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:52:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 17:56:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:41:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:42:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:17 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-05-09 22:43:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:43:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 22:44:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:04:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:06:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:07:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:31:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:32:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-05-09 23:33:05 --> 404 Page Not Found: An-theme/ando
