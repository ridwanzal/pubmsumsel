<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-21 04:45:52 --> 404 Page Not Found: AN_admin/images
ERROR - 2019-04-21 04:46:00 --> 404 Page Not Found: AN_admin/login.php
ERROR - 2019-04-21 04:46:03 --> 404 Page Not Found: Templates/system
ERROR - 2019-04-21 07:35:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 07:35:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 07:35:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 16:53:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 16:53:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 16:53:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 16:53:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 16:53:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 17:31:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 17:31:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 17:31:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 23:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-21 23:16:32 --> Severity: Warning --> opendir(/var/cpanel/php/sessions/ea3): failed to open dir: Permission denied /home/puprmuaraenimkab/public_html/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2019-04-21 23:16:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-21 23:16:53 --> 404 Page Not Found: An-theme/ando
