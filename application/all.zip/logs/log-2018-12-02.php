<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-02 14:17:33 --> 404 Page Not Found: Img/pu.png
