<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-01 01:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-01 04:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-01 04:26:07 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2019-03-01 11:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-01 14:39:30 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-03-01 15:02:06 --> 404 Page Not Found: Bidang/uploads
