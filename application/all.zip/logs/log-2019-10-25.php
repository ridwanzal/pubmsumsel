<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-25 16:23:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-10-25 16:23:46 --> Unable to connect to the database
ERROR - 2019-10-25 16:23:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-10-25 16:23:59 --> Unable to connect to the database
ERROR - 2019-10-25 16:23:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-10-25 16:23:59 --> Unable to connect to the database
ERROR - 2019-10-25 16:24:05 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-10-25 16:24:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 1079
ERROR - 2019-10-25 16:25:16 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-10-25 16:25:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:25:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:38:19 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-10-25 16:38:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 1079
ERROR - 2019-10-25 16:40:04 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-10-25 16:40:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:40:37 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:02 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:05 --> Severity: error --> Exception: Call to a member function result() on boolean C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 129
ERROR - 2019-10-25 16:42:09 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:18 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2019-10-25 16:42:21 --> Severity: error --> Exception: Call to a member function result() on boolean C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 129
ERROR - 2019-10-25 16:47:33 --> Severity: Compile Error --> Cannot redeclare AN_admin::struktur_organisasi() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 702
ERROR - 2019-10-25 16:50:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:50:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:21 --> 404 Page Not Found: AN_admin/bidang_jamabtan
ERROR - 2019-10-25 16:51:35 --> 404 Page Not Found: AN_admin/bidang_jamabtan
ERROR - 2019-10-25 16:51:38 --> 404 Page Not Found: AN_admin/bidang_jembatan
ERROR - 2019-10-25 16:51:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 27
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 28
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 34
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 38
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: list_kategori C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 46
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 67
ERROR - 2019-10-25 16:51:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 67
ERROR - 2019-10-25 16:51:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:51:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:54:56 --> Severity: Notice --> Undefined variable: get_struktur_organisasi C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 723
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 27
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 28
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 34
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 38
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: list_kategori C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 46
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 67
ERROR - 2019-10-25 16:59:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang.php 67
ERROR - 2019-10-25 16:59:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:59:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 16:59:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:00:48 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang_jabatan.php 32
ERROR - 2019-10-25 17:01:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang_jabatan.php 32
ERROR - 2019-10-25 17:01:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:01:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:01:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:03:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:03:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:03:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:03:42 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\pubmsumsel\application\views\admin\bidang_jabatan.php 33
ERROR - 2019-10-25 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:04:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:04:43 --> 404 Page Not Found: Uploads/struktur_organisasi
ERROR - 2019-10-25 17:07:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:07:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:07:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:07:06 --> 404 Page Not Found: Uploads/struktur_organisasi
ERROR - 2019-10-25 17:09:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:09:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:10:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:11:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:12:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:13:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:16:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:16:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:16:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:16:22 --> Severity: error --> Exception: Too few arguments to function AN_admin::edit_jabatan(), 0 passed in C:\xampp\htdocs\pubmsumsel\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 748
ERROR - 2019-10-25 17:17:14 --> Severity: Notice --> Undefined property: AN_admin::$view C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:17:14 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:17:49 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:17:49 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 750
ERROR - 2019-10-25 17:17:49 --> Severity: error --> Exception: Call to undefined function prin_r() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 752
ERROR - 2019-10-25 17:42:39 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:42:39 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 750
ERROR - 2019-10-25 17:42:39 --> Severity: error --> Exception: Call to undefined function prin_r() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 752
ERROR - 2019-10-25 17:42:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:42:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:42:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:43:29 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 750
ERROR - 2019-10-25 17:43:40 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:43:40 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 750
ERROR - 2019-10-25 17:43:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:43:44 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 749
ERROR - 2019-10-25 17:43:44 --> Severity: Notice --> Undefined variable: nama C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 750
ERROR - 2019-10-25 17:44:26 --> Severity: error --> Exception: Too few arguments to function AN_admin::edit_jabatan(), 0 passed in C:\xampp\htdocs\pubmsumsel\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 748
ERROR - 2019-10-25 17:44:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:44:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:44:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:44:35 --> Severity: error --> Exception: Too few arguments to function AN_admin::edit_jabatan(), 0 passed in C:\xampp\htdocs\pubmsumsel\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 748
ERROR - 2019-10-25 17:47:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:47:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:47:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:47:07 --> Query error: Duplicate entry '1' for key 'PRIMARY' - Invalid query: UPDATE `jabatan` SET `jabatan_id` = '1', `jabatan_nama` = 'Plt. Kepala Dinas s'
ERROR - 2019-10-25 17:47:55 --> Query error: Unknown column 'jabtan_id' in 'where clause' - Invalid query: UPDATE `jabatan` SET `jabatan_nama` = 'Plt. Kepala Dinas s'
WHERE `jabtan_id` = '1'
ERROR - 2019-10-25 17:48:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:48:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:48:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:48:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:48:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:48:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:49:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-10-25 17:51:23 --> 404 Page Not Found: An-theme/admin
