<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 02:44:47 --> Severity: Notice --> Undefined variable: ig /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-24 02:44:47 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-24 03:13:01 --> Severity: Notice --> Undefined variable: ig /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-24 03:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
