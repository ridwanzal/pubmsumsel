<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-14 01:13:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-14 05:37:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-14 05:37:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-14 05:37:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-14 09:57:37 --> 404 Page Not Found: AN_admin/images
ERROR - 2019-03-14 09:57:51 --> 404 Page Not Found: AN_admin/login.php
ERROR - 2019-03-14 09:58:03 --> 404 Page Not Found: Templates/system
ERROR - 2019-03-14 09:58:19 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2019-03-14 10:26:02 --> 404 Page Not Found: AN_admin/images
ERROR - 2019-03-14 10:26:10 --> 404 Page Not Found: AN_admin/login.php
ERROR - 2019-03-14 10:26:21 --> 404 Page Not Found: Templates/system
ERROR - 2019-03-14 10:26:31 --> 404 Page Not Found: Fckeditor/editor
