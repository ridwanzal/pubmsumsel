<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-22 02:35:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:35:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:35:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-22 02:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-22 02:42:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:42:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:42:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 02:43:48 --> 404 Page Not Found: Unit_kerja/index
ERROR - 2019-03-22 05:28:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:28:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:28:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:28:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:28:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:29:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:29:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:29:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:29:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 05:29:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 06:46:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 06:46:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 06:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 15:58:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 15:58:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-22 15:58:30 --> 404 Page Not Found: An-theme/ando
