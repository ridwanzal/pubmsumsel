<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-13 21:39:41 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:06 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:23 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:36 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:50 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:55 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:07 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:11 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:14 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:21 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:27 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:43:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:44:00 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:44:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:44:16 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:44:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:48:20 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:13 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:41 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:49 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:50:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:21 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:44 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:48 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:56 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 21:51:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:19:33 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:21:22 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:21:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:25:57 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:26:19 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:27:39 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-13 22:27:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
