<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-11 00:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-11 00:15:00 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2019-04-11 05:00:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 05:00:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 05:00:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 05:08:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 05:08:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 05:08:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:38:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:38:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:38:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-11 06:55:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:55:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 06:55:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 09:11:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 09:11:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 09:11:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 17:52:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:20:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:20:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:20:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:20:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:20:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:29:12 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-04-11 18:29:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-11 18:29:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-11 18:29:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-11 18:29:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:34 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-04-11 18:29:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-11 18:29:40 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-04-11 18:29:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-11 18:29:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:29:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:29:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:29:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:29:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:29:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:30:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:30:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:30:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:30:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:30:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:32:10 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:32:46 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:33:05 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:33:15 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:33:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:33:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:37:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:37:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:38:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:40:54 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /home/puprmuaraenimkab/public_html/application/views/ando/home.php 197
ERROR - 2019-04-11 18:41:06 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) /home/puprmuaraenimkab/public_html/application/views/ando/home.php 197
ERROR - 2019-04-11 18:41:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:40 --> Severity: Notice --> Undefined variable: artikel_berita /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:41:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:41:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/Home.php:32) /home/puprmuaraenimkab/public_html/system/core/Common.php 564
ERROR - 2019-04-11 18:44:08 --> Severity: Error --> Call to undefined method Artikel::artike_berita() /home/puprmuaraenimkab/public_html/application/controllers/Home.php 32
ERROR - 2019-04-11 18:44:29 --> Severity: Notice --> Undefined variable: artikel_berita /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:39 --> Severity: Notice --> Undefined variable: artikel_berita /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:55 --> Severity: Notice --> Undefined variable: artikel_berita /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/puprmuaraenimkab/public_html/application/views/ando/home.php 184
ERROR - 2019-04-11 18:44:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:44:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:45:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:45:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 1 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 151
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 2 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 204
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 1 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 151
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 2 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 204
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 192
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 1 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 151
ERROR - 2019-04-11 18:46:41 --> Severity: Notice --> Undefined offset: 2 /home/puprmuaraenimkab/public_html/application/helpers/front_end_helper.php 204
ERROR - 2019-04-11 18:46:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:46:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:46:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:46:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:46:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:48:02 --> Severity: Parsing Error --> syntax error, unexpected '"', expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/puprmuaraenimkab/public_html/application/views/ando/home.php 188
ERROR - 2019-04-11 18:49:05 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:05 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:05 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:13 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:13 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:13 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:18 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:18 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:18 --> Severity: Notice --> Trying to get property of non-object /home/puprmuaraenimkab/public_html/application/views/ando/home.php 193
ERROR - 2019-04-11 18:49:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:49:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:50:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:52:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:53:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:53:56 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:54:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:54:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:54:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:55:20 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:55:27 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:27 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:27 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:27 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:27 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:55:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:55:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:55:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:56:13 --> Severity: Warning --> escapeshellarg() has been disabled for security reasons /home/puprmuaraenimkab/public_html/system/libraries/Upload.php 1261
ERROR - 2019-04-11 18:56:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:56:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:56:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:56:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-11 18:56:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-11 18:56:40 --> 404 Page Not Found: An-theme/ando
