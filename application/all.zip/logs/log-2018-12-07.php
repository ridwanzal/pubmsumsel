<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-07 05:16:32 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-07 05:16:32 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-07 05:16:52 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-07 05:16:57 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-07 07:16:04 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-07 07:16:04 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-07 08:58:14 --> Severity: error --> Exception: syntax error, unexpected end of file /opt/lampp/htdocs/dinaspu/application/views/admin/header.php 352
ERROR - 2018-12-07 09:03:02 --> 404 Page Not Found: AN_admin/data_infrastruktur
ERROR - 2018-12-07 09:48:18 --> Severity: error --> Exception: syntax error, unexpected '}' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 519
ERROR - 2018-12-07 10:29:43 --> 404 Page Not Found: AN_admin/infrastruktur
ERROR - 2018-12-07 10:30:03 --> 404 Page Not Found: AN_admin/data_infrastruktur
ERROR - 2018-12-07 10:30:29 --> 404 Page Not Found: AN_admin/data_infrastruktur
