<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 21:06:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'puprmuar_dpu' C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-06-03 21:06:13 --> Unable to connect to the database
ERROR - 2020-06-03 21:06:42 --> Severity: Notice --> unserialize(): Error at offset 749 of 1448 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-03 21:06:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-03 21:06:42 --> Query error: Table 'puprmuar_dpu.informasi' doesn't exist - Invalid query: SELECT *
FROM `informasi`
WHERE `id` = 1
ERROR - 2020-06-03 21:06:44 --> Severity: Notice --> unserialize(): Error at offset 749 of 1448 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-03 21:06:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-03 21:06:44 --> Query error: Table 'puprmuar_dpu.informasi' doesn't exist - Invalid query: SELECT *
FROM `informasi`
WHERE `id` = 1
ERROR - 2020-06-03 21:08:23 --> Severity: Notice --> unserialize(): Error at offset 749 of 1448 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-03 21:08:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-03 21:08:24 --> Severity: Notice --> unserialize(): Error at offset 2050 of 22893 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-03 21:08:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-03 21:08:24 --> Severity: Notice --> unserialize(): Error at offset 5033 of 28611 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-03 21:08:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-03 21:08:24 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-03 21:08:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:25 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:33 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-03 21:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-03 21:08:33 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-03 21:08:34 --> 404 Page Not Found: An-component/media
