<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-06 19:48:48 --> 404 Page Not Found: Wp-loginphp/index
