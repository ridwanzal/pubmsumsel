<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-23 07:59:07 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-23 07:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:12 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 07:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:00:02 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-23 08:00:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:00:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:00:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:00:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:00:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:00:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:01:27 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-23 08:01:40 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-23 08:01:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:01:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:01:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:01:59 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-23 08:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:01 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:01 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-23 08:02:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:02:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:03:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:31:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:31:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:31:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 08:31:27 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 19
ERROR - 2020-06-23 08:31:41 --> 404 Page Not Found: PDF/1
ERROR - 2020-06-23 08:32:09 --> 404 Page Not Found: PDF/1
ERROR - 2020-06-23 08:32:24 --> 404 Page Not Found: PDF/1
ERROR - 2020-06-23 08:32:43 --> Severity: Warning --> require_once(C:\xampp\htdocs\pubmsumsel\application\third_party/fpdf/fpdf-1.8.php): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 8
ERROR - 2020-06-23 08:32:43 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\pubmsumsel\application\third_party/fpdf/fpdf-1.8.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 8
ERROR - 2020-06-23 08:32:55 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 13
ERROR - 2020-06-23 08:32:55 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:32:55 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:09 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 13
ERROR - 2020-06-23 08:35:09 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:09 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:12 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 13
ERROR - 2020-06-23 08:35:12 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:12 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:20 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:35:20 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 15
ERROR - 2020-06-23 08:35:20 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 15
ERROR - 2020-06-23 08:36:19 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:36:19 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 15
ERROR - 2020-06-23 08:36:19 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 15
ERROR - 2020-06-23 08:37:30 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 13
ERROR - 2020-06-23 08:37:30 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:37:30 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:37:53 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 13
ERROR - 2020-06-23 08:37:53 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:37:53 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 14
ERROR - 2020-06-23 08:38:08 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 11
ERROR - 2020-06-23 08:38:08 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 11
ERROR - 2020-06-23 08:38:25 --> Severity: Notice --> Undefined property: Pdf::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 10
ERROR - 2020-06-23 08:38:25 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 10
ERROR - 2020-06-23 08:38:31 --> Severity: Notice --> Undefined property: PDF::$load C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 10
ERROR - 2020-06-23 08:38:31 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 10
ERROR - 2020-06-23 08:39:14 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:14 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:14 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:15 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:15 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file (output started at C:\xampp\htdocs\pubmsumsel\system\core\Exceptions.php:271) C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-06-23 08:39:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pubmsumsel\system\core\Exceptions.php:271) C:\xampp\htdocs\pubmsumsel\system\core\Common.php 570
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 38
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:20 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:20 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file (output started at C:\xampp\htdocs\pubmsumsel\system\core\Exceptions.php:271) C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-06-23 08:39:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pubmsumsel\system\core\Exceptions.php:271) C:\xampp\htdocs\pubmsumsel\system\core\Common.php 570
ERROR - 2020-06-23 08:39:40 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 16
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'no_ktp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 39
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:48 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 44
ERROR - 2020-06-23 08:39:48 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-06-23 08:39:57 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 40
ERROR - 2020-06-23 08:39:57 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 41
ERROR - 2020-06-23 08:39:57 --> Severity: Notice --> Trying to get property 'no_hp' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 42
ERROR - 2020-06-23 08:39:57 --> Severity: Notice --> Trying to get property 'jenis_pengujian' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 43
ERROR - 2020-06-23 08:39:57 --> Severity: Notice --> Trying to get property 'created_at' of non-object C:\xampp\htdocs\pubmsumsel\application\controllers\PDF.php 44
ERROR - 2020-06-23 08:39:57 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-06-23 09:12:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 09:12:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 09:12:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 09:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 09:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-23 09:13:01 --> 404 Page Not Found: An-theme/admin
