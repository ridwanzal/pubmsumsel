<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-28 23:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-28 23:09:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-28 23:09:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-28 23:09:46 --> 404 Page Not Found: Faviconico/index
