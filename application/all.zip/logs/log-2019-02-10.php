<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-10 01:39:37 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-02-10 08:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-10 08:29:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-10 08:29:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-10 08:29:41 --> 404 Page Not Found: An-theme/ando
