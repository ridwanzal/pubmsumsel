<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-16 06:54:22 --> 404 Page Not Found: Robotstxt/index
