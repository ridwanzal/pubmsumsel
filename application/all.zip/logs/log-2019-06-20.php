<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-20 03:24:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-20 03:24:03 --> Unable to connect to the database
ERROR - 2019-06-20 18:34:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-20 18:34:12 --> Unable to connect to the database
ERROR - 2019-06-20 18:34:35 --> Severity: Notice --> unserialize(): Error at offset 2050 of 28246 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2019-06-20 18:39:35 --> Severity: Notice --> Undefined variable: get_kontak C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 751
ERROR - 2019-06-20 18:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 751
ERROR - 2019-06-20 18:39:54 --> Severity: Notice --> Undefined property: Home::$Kontak_masuk C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 26
ERROR - 2019-06-20 18:39:54 --> Severity: error --> Exception: Call to a member function get_data() on null C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 26
ERROR - 2019-06-20 19:10:23 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:10:23 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:10:24 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:10:24 --> 404 Page Not Found: Images/model-1.png
ERROR - 2019-06-20 19:10:24 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:10:24 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 19:11:24 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:11:24 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:11:24 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:11:24 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 19:11:24 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:12:16 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:12:16 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:12:58 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:12:58 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:13:39 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:13:39 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:13:51 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:13:51 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:12 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:14:12 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:37 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:37 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:14:44 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:44 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:14:52 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:52 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:14:57 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:14:57 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:15:06 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:15:06 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:16:13 --> 404 Page Not Found: Images/shopping-bag.png
ERROR - 2019-06-20 19:16:13 --> 404 Page Not Found: Images/logo.png
ERROR - 2019-06-20 19:20:04 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:20:04 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:20:04 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 19:20:25 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:20:25 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:20:25 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 19:20:49 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:20:49 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:20:49 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 19:22:12 --> 404 Page Not Found: Images/model-2.png
ERROR - 2019-06-20 19:22:12 --> 404 Page Not Found: Images/model-3.png
ERROR - 2019-06-20 19:22:12 --> 404 Page Not Found: Images/model-4.png
ERROR - 2019-06-20 20:08:28 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:12:50 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-06-20 20:12:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:12:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:12:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:12:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:12:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:12:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:13:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:14:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:41:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-20 20:43:07 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:44:29 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 248
ERROR - 2019-06-20 20:44:44 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 248
ERROR - 2019-06-20 20:44:52 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 248
ERROR - 2019-06-20 20:45:33 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:46:15 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 248
ERROR - 2019-06-20 20:46:32 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:46:58 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:47:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:47:09 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:47:16 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 20:48:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:48:27 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:48:32 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:48:37 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:48:42 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:48:52 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:49:15 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:49:18 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:49:21 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:50:14 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:50:28 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:50:38 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 250
ERROR - 2019-06-20 20:50:48 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:51:42 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 245
ERROR - 2019-06-20 20:51:55 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 245
ERROR - 2019-06-20 20:52:11 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 246
ERROR - 2019-06-20 20:52:32 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 247
ERROR - 2019-06-20 20:52:45 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 248
ERROR - 2019-06-20 20:52:50 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:53:42 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:53:47 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:31 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:35 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:43 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:48 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:54 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:54:58 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:08 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:15 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:19 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:22 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:30 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:55:55 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:04 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:21 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:28 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:37 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:50 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:56:54 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:57:00 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:57:07 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:57:13 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:57:26 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:57:35 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:59:34 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:59:44 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 20:59:53 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 21:00:00 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 21:00:31 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 21:00:41 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 21:01:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-06-20 21:01:17 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 246
ERROR - 2019-06-20 21:01:54 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:02:05 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:02:19 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:02:32 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:02:39 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:02:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 249
ERROR - 2019-06-20 21:03:41 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 264
ERROR - 2019-06-20 21:03:46 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 262
ERROR - 2019-06-20 21:04:00 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 261
ERROR - 2019-06-20 21:04:03 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 259
ERROR - 2019-06-20 21:04:39 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:04:56 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:04:58 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:05:07 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:05:08 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:05:21 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:06:13 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:06:18 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:06:30 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 258
ERROR - 2019-06-20 21:06:46 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:06:50 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:07:04 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:07:54 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:05 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:09 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:16 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:23 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:26 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:30 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:36 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:39 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:08:42 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:09:05 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:09:22 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:10:16 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:10:30 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:10:33 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:10:40 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:12:23 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:12:24 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:22:36 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:30:35 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:30:37 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:31:27 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 21:41:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 477
ERROR - 2019-06-20 21:42:06 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 477
ERROR - 2019-06-20 21:46:56 --> Severity: Notice --> Undefined variable: pagename C:\xampp\htdocs\pubmsumsel\application\views\ando\header.php 243
ERROR - 2019-06-20 21:54:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-06-20 22:48:05 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 267
ERROR - 2019-06-20 22:48:25 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:48:36 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:48:47 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 256
ERROR - 2019-06-20 22:49:00 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:49:21 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:49:29 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:49:40 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:49:46 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:49:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:01 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:07 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:20 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:23 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:50 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:56 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:50:59 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:51:04 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 22:56:43 --> 404 Page Not Found: Page/images
ERROR - 2019-06-20 22:58:43 --> 404 Page Not Found: Page/images
ERROR - 2019-06-20 22:59:02 --> 404 Page Not Found: Page/images
ERROR - 2019-06-20 23:09:00 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 23:09:19 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 23:10:26 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 257
ERROR - 2019-06-20 23:10:40 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 8
ERROR - 2019-06-20 23:10:40 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 312
ERROR - 2019-06-20 23:10:51 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 312
ERROR - 2019-06-20 23:11:47 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 312
ERROR - 2019-06-20 23:12:05 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-20 23:12:58 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-20 23:13:09 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 311
ERROR - 2019-06-20 23:13:14 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
