<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 04:30:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:30:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 04:38:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:35:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:35:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:35:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:35:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:35:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:40:12 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-04-08 11:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 11:41:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-08 11:43:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-04-08 11:44:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 145
ERROR - 2019-04-08 11:44:35 --> Severity: Notice --> Undefined index: id /home/puprmuaraenimkab/public_html/application/views/admin/galeri.php 146
ERROR - 2019-04-08 11:44:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:44:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-04-08 11:45:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:45:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:45:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:45:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:45:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:46:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:24 --> Severity: Warning --> opendir(/var/cpanel/php/sessions/ea3): failed to open dir: Permission denied /home/puprmuaraenimkab/public_html/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2019-04-08 11:48:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:48:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:50:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:53:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:22 --> Severity: Notice --> Undefined index: gambars /home/puprmuaraenimkab/public_html/application/views/ando/home.php 133
ERROR - 2019-04-08 11:54:22 --> Severity: Notice --> Undefined index: gambars /home/puprmuaraenimkab/public_html/application/views/ando/home.php 133
ERROR - 2019-04-08 11:54:22 --> Severity: Notice --> Undefined index: gambars /home/puprmuaraenimkab/public_html/application/views/ando/home.php 133
ERROR - 2019-04-08 11:54:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:54:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:58:55 --> Non-existent class: Banner_depan
ERROR - 2019-04-08 11:58:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 11:59:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 11:59:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:03:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:04:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:04:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:04:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:04:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:04:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:05:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:05:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:05:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:05:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 12:05:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-08 16:03:08 --> 404 Page Not Found: User/register
ERROR - 2019-04-08 16:03:16 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:03:23 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:03:30 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:03:38 --> 404 Page Not Found: Administrator/index
ERROR - 2019-04-08 16:03:44 --> 404 Page Not Found: Administrator/webconfig.txt.php
ERROR - 2019-04-08 16:04:21 --> 404 Page Not Found: User/register
ERROR - 2019-04-08 16:04:29 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:04:37 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:04:50 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:05:02 --> 404 Page Not Found: Administrator/index
ERROR - 2019-04-08 16:05:10 --> 404 Page Not Found: Administrator/webconfig.txt.php
ERROR - 2019-04-08 16:23:00 --> 404 Page Not Found: User/register
ERROR - 2019-04-08 16:23:02 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:23:05 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:23:07 --> 404 Page Not Found: Administrator/index
ERROR - 2019-04-08 16:23:09 --> 404 Page Not Found: Administrator/webconfig.txt.php
ERROR - 2019-04-08 16:23:28 --> 404 Page Not Found: User/register
ERROR - 2019-04-08 16:23:34 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:23:37 --> 404 Page Not Found: Wp-admin/admin-post.php
ERROR - 2019-04-08 16:23:39 --> 404 Page Not Found: Administrator/index
ERROR - 2019-04-08 16:23:43 --> 404 Page Not Found: Administrator/webconfig.txt.php
