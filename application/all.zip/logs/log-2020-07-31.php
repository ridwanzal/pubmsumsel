<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-31 19:50:18 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-31 19:50:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-31 19:50:26 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:26 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:26 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 19:50:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-31 20:04:54 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-07-31 20:07:32 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\pubmsumsel\application\views\admin\header.php 367
ERROR - 2020-07-31 20:07:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:07:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:07:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:08:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:08:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:08:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:09:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:09:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:09:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:14:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:14:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:14:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:15:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:15:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:15:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:16:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:18:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:18:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:18:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:20:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:20:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:20:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:37:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:37:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:37:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:37:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:37:08 --> Severity: error --> Exception: Class 'FPDF' not found C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1392
ERROR - 2020-07-31 20:37:32 --> Severity: error --> Exception: Class 'FPDF' not found C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 19
ERROR - 2020-07-31 20:43:22 --> Severity: error --> Exception: FPDF error: Incorrect output destination: http://localhost/pubmsumsel/assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:43:54 --> Severity: error --> Exception: FPDF error: Incorrect output destination: http://localhost/pubmsumsel/assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:44:10 --> Severity: error --> Exception: FPDF error: Incorrect output destination: http://localhost/pubmsumsel/assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:45:12 --> Severity: Warning --> file_put_contents(http://localhost/pubmsumsel/assets/uploads/pengujian/2): failed to open stream: HTTP wrapper does not support writeable connections C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 1021
ERROR - 2020-07-31 20:45:12 --> Severity: error --> Exception: FPDF error: Unable to create output file: http://localhost/pubmsumsel/assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:45:57 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1427
ERROR - 2020-07-31 20:46:12 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1427
ERROR - 2020-07-31 20:46:34 --> Severity: Warning --> file_put_contents(/assets/uploads/pengujian/2): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 1021
ERROR - 2020-07-31 20:46:34 --> Severity: error --> Exception: FPDF error: Unable to create output file: /assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:47:36 --> Severity: Warning --> file_put_contents(../assets/uploads/pengujian/2): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 1021
ERROR - 2020-07-31 20:47:36 --> Severity: error --> Exception: FPDF error: Unable to create output file: ../assets/uploads/pengujian/2 C:\xampp\htdocs\pubmsumsel\application\third_party\fpdf\fpdf.php 271
ERROR - 2020-07-31 20:54:38 --> Severity: Notice --> Undefined variable: files C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:54:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:54:38 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:54:38 --> Severity: Warning --> readfile(2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:54:56 --> Severity: Notice --> Undefined variable: files C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:54:56 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:54:56 --> Severity: Warning --> readfile(2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:55:00 --> Severity: Notice --> Undefined variable: files C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1439
ERROR - 2020-07-31 20:55:00 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:55:00 --> Severity: Warning --> readfile(2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:56:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2020-07-31 20:56:28 --> Severity: Warning --> file_get_contents(http://localhost/pubmsumsel/assets/uploads/pengujain/2.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1440
ERROR - 2020-07-31 20:56:28 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:56:28 --> Severity: Warning --> readfile(2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:57:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:06 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:57:06 --> Severity: Warning --> readfile(2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:57:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:57:51 --> Severity: Warning --> filesize(): stat failed for 2_Sultan Muhammad C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:57:51 --> Severity: Warning --> readfile(2_Sultan Muhammad): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:58:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:58:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:58:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:58:35 --> Severity: Warning --> filesize(): stat failed for Dokumen_pengujian_2_Sultan Muhammad C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:58:35 --> Severity: Warning --> readfile(Dokumen_pengujian_2_Sultan Muhammad): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 20:59:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 20:59:44 --> Severity: Warning --> filesize(): stat failed for Dokumen_pengujian_2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 20:59:44 --> Severity: Warning --> readfile(Dokumen_pengujian_2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 21:01:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:01:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:01:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:01:37 --> Severity: Warning --> readfile(Dokumen_pengujian_2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 21:06:45 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\pubmsumsel\assets/uploads/zip/Dokumen_pengujian_2_Sultan Muhammad.zip C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1449
ERROR - 2020-07-31 21:06:46 --> Severity: Warning --> readfile(C:\xampp\htdocs\pubmsumsel\assets/uploads/zip/Dokumen_pengujian_2_Sultan Muhammad.zip): failed to open stream: No such file or directory C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1450
ERROR - 2020-07-31 21:15:26 --> Severity: Warning --> file_exists() expects parameter 1 to be a valid path, array given C:\xampp\htdocs\pubmsumsel\system\libraries\Zip.php 316
ERROR - 2020-07-31 21:23:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:23:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:23:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:23:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:24:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:24:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:24:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:26:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:26:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:26:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:27:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:27:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:27:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:27:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:28 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-07-31 21:28:52 --> 404 Page Not Found: An-theme/admin
