<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-02 17:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-02 17:48:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-02 17:48:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-02 17:48:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-02 17:48:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-02 17:48:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-02 21:32:51 --> 404 Page Not Found: Faviconico/index
