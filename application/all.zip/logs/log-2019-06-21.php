<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-21 03:15:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-21 03:15:49 --> Unable to connect to the database
ERROR - 2019-06-21 03:15:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-21 03:15:54 --> Unable to connect to the database
ERROR - 2019-06-21 03:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-21 03:16:01 --> Unable to connect to the database
ERROR - 2019-06-21 03:16:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-06-21 03:16:09 --> Unable to connect to the database
ERROR - 2019-06-21 03:16:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:17:17 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:17:36 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:18:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:18:56 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:19:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:19:17 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:19:21 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:19:27 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-21 03:20:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
