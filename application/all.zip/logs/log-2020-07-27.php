<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-27 19:29:48 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-27 19:29:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:29:51 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:18 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-27 19:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-07-27 19:53:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
ERROR - 2020-07-27 19:53:21 --> 404 Page Not Found: An-component/media
