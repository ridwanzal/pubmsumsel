<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-25 02:46:24 --> Severity: Notice --> unserialize(): Error at offset 1107 of 1169 bytes /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2019-04-25 02:46:24 --> Severity: Warning --> chmod(): Operation not permitted /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 106
ERROR - 2019-04-25 02:50:44 --> Severity: Notice --> unserialize(): Error at offset 1107 of 1160 bytes /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2019-04-25 02:50:44 --> Severity: Warning --> chmod(): Operation not permitted /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 106
ERROR - 2019-04-25 02:53:35 --> Severity: Notice --> unserialize(): Error at offset 193 of 1088 bytes /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2019-04-25 02:53:35 --> Severity: Warning --> chmod(): Operation not permitted /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 106
ERROR - 2019-04-25 02:55:03 --> Severity: Notice --> unserialize(): Error at offset 438 of 1337 bytes /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2019-04-25 02:55:03 --> Severity: Warning --> chmod(): Operation not permitted /opt/lampp/htdocs/dpunew/system/libraries/Cache/drivers/Cache_file.php 106
ERROR - 2019-04-25 11:19:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-25 11:20:01 --> 404 Page Not Found: An-theme/ando
