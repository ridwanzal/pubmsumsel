<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-07 06:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-07 06:10:23 --> 404 Page Not Found: Unit_kerja/index
ERROR - 2019-02-07 06:10:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:10:25 --> 404 Page Not Found: Unit_kerja/index
ERROR - 2019-02-07 06:10:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-02-07 06:10:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:10:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:11:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:12:00 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:12:03 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:13:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:13:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-07 06:15:07 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:15:11 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:15:51 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:17:27 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 06:17:49 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 07:46:26 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 07:49:27 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-02-07 08:09:26 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 08:10:26 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 08:55:25 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 09:53:33 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 10:20:43 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-02-07 10:32:31 --> 404 Page Not Found: Bidang/uploads
