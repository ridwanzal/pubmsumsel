<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-08 00:09:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:09:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:09:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:09:15 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-08 00:09:44 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-08 00:10:59 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-08 00:11:09 --> Severity: error --> Exception: Class 'PhpOffice\PhpWord\PhpWord' not found C:\xampp\htdocs\pubmsumsel\application\controllers\Pengujian.php 14
ERROR - 2020-06-08 00:13:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:13:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:13:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:19 --> 404 Page Not Found: 
ERROR - 2020-06-08 00:14:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-08 00:14:58 --> 404 Page Not Found: An-theme/admin
