<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-23 04:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-23 08:16:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-23 08:16:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-23 08:16:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-02-23 09:15:52 --> 404 Page Not Found: Faviconico/index
