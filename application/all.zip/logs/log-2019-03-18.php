<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-18 02:22:05 --> 404 Page Not Found: Bidang/uploads
ERROR - 2019-03-18 02:22:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-18 15:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-18 15:29:29 --> 404 Page Not Found: Well-known/assetlinks.json
