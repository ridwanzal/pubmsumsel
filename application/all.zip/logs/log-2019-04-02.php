<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-02 17:09:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 17:09:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-02 23:27:11 --> 404 Page Not Found: Faviconico/index
