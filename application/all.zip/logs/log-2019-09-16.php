<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-16 21:31:38 --> Severity: Notice --> unserialize(): Error at offset 749 of 1448 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2019-09-16 21:31:39 --> Severity: Notice --> unserialize(): Error at offset 2050 of 30326 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2019-09-16 21:31:39 --> Severity: Notice --> unserialize(): Error at offset 4200 of 32084 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2019-09-16 21:42:10 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-09-16 21:42:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:42:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:43:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:43:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:43:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:47:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-16 21:48:14 --> 404 Page Not Found: An-theme/admin
