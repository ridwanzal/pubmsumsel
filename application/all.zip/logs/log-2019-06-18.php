<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-18 09:00:27 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: Temporary failure in name resolution /opt/lampp/htdocs/pubmsumsel/application/controllers/Home.php 42
ERROR - 2019-06-18 09:00:27 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: php_network_getaddresses: getaddrinfo failed: Temporary failure in name resolution /opt/lampp/htdocs/pubmsumsel/application/controllers/Home.php 42
ERROR - 2019-06-18 09:00:27 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 708
ERROR - 2019-06-18 09:15:22 --> 404 Page Not Found: Wow%20fadeIn%20delay-1s/index
ERROR - 2019-06-18 09:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 708
ERROR - 2019-06-18 09:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 708
ERROR - 2019-06-18 09:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 708
ERROR - 2019-06-18 09:27:04 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 708
