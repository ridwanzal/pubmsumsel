<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-07 06:22:59 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 06:22:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:23:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 06:32:24 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-07 06:32:28 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-07 06:32:33 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-07 06:33:37 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-07 06:34:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 06:34:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 06:34:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 06:34:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 06:34:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 06:34:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:03:09 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:03:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:03:10 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:11:59 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:12:00 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:01 --> Severity: Notice --> unserialize(): Error at offset 1047 of 1091 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2020-06-07 13:13:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 277
ERROR - 2020-06-07 13:13:02 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:02 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:03 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:19 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:19 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:19 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:20 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:26 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:26 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:26 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:27 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:13:52 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:14:40 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:14:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:14:48 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:14:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:15:11 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:15:14 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:15:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:15:14 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 13:25:23 --> Severity: Notice --> Undefined index: no_ktp C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1415
ERROR - 2020-06-07 13:25:23 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1416
ERROR - 2020-06-07 13:25:23 --> Severity: Notice --> Undefined index: no_hp C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1417
ERROR - 2020-06-07 13:25:23 --> Severity: Notice --> Undefined index: surat C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1419
ERROR - 2020-06-07 13:26:26 --> Severity: Notice --> Undefined index: surat C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1419
ERROR - 2020-06-07 13:37:01 --> Severity: Notice --> Undefined index: surat C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1419
ERROR - 2020-06-07 13:37:01 --> Severity: Notice --> Undefined index: surat C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1429
ERROR - 2020-06-07 13:37:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1429
ERROR - 2020-06-07 13:38:02 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\pubmsumsel\application\views\ando\form_pengujian.php 14
ERROR - 2020-06-07 13:41:55 --> Severity: error --> Exception: Class 'MY_Controller' not found C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 4
ERROR - 2020-06-07 13:44:21 --> Severity: error --> Exception: Class 'MY_Controller' not found C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 4
ERROR - 2020-06-07 13:44:31 --> Severity: error --> Exception: Class 'AN_Controller' not found C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 4
ERROR - 2020-06-07 13:50:47 --> Query error: Unknown column 'created_at' in 'field list' - Invalid query: INSERT INTO `pengujian` (`nama`, `alamat`, `no_ktp`, `email`, `no_hp`, `jenis_pengujian`, `created_at`, `surat`) VALUES ('sdfsdf', 'sdfsd', 'sdfs', 'sdf@g.com', 'sdfs', 'Pengujian Bahan Konstruksi (Tanah)', '2020-06-07 13:50:47', 'covid1.png')
ERROR - 2020-06-07 13:52:51 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-07 13:52:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:52:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:52:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:52:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:54:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:55:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:56:32 --> Severity: Notice --> Undefined index: dibaca C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 38
ERROR - 2020-06-07 13:56:32 --> Severity: Notice --> Undefined index: ktp C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 41
ERROR - 2020-06-07 13:56:32 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 43
ERROR - 2020-06-07 13:56:32 --> Severity: Notice --> Undefined index: pesan C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 44
ERROR - 2020-06-07 13:56:32 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 45
ERROR - 2020-06-07 13:56:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:56:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:56:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:57:23 --> Severity: Notice --> Undefined index: dibaca C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 38
ERROR - 2020-06-07 13:57:23 --> Severity: Notice --> Undefined index: ktp C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 41
ERROR - 2020-06-07 13:57:23 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 43
ERROR - 2020-06-07 13:57:23 --> Severity: Notice --> Undefined index: pesan C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 44
ERROR - 2020-06-07 13:57:23 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 45
ERROR - 2020-06-07 13:57:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:57:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:57:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:02 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-07 13:58:04 --> Severity: Notice --> Undefined index: dibaca C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 38
ERROR - 2020-06-07 13:58:04 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 45
ERROR - 2020-06-07 13:58:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:26 --> Severity: Notice --> Undefined variable: style C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 38
ERROR - 2020-06-07 13:58:26 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 44
ERROR - 2020-06-07 13:58:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:45 --> Severity: Notice --> Undefined index: tanggal C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 44
ERROR - 2020-06-07 13:58:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:58:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 13:59:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:00:46 --> Severity: error --> Exception: syntax error, unexpected '?' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:03 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:20 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:26 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:01:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:01:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:01:44 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:48 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:01:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:01:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:01:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:02:16 --> Severity: error --> Exception: syntax error, unexpected '"', expecting ')' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 47
ERROR - 2020-06-07 14:03:03 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:03:14 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:03:21 --> Severity: error --> Exception: syntax error, unexpected '"', expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:03:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:03:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:03:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 14:03:53 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:04:02 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:04:05 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 14:04:10 --> Severity: error --> Exception: syntax error, unexpected 'base_url' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 48
ERROR - 2020-06-07 22:59:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 22:59:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 22:59:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 22:59:11 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 22:59:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:13 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-07 22:59:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:00:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:00:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:00:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:29:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:29:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-07 23:29:56 --> 404 Page Not Found: An-theme/admin
