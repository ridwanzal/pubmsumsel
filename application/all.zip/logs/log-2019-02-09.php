<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-09 15:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-09 15:18:43 --> 404 Page Not Found: Well-known/assetlinks.json
