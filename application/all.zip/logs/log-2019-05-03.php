<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-03 03:33:26 --> 404 Page Not Found: Login/index
ERROR - 2019-05-03 03:33:55 --> 404 Page Not Found: Login/index
ERROR - 2019-05-03 04:06:12 --> 404 Page Not Found: 
ERROR - 2019-05-03 04:06:30 --> 404 Page Not Found: 
ERROR - 2019-05-03 04:06:43 --> 404 Page Not Found: 
ERROR - 2019-05-03 04:07:43 --> 404 Page Not Found: Login/index
ERROR - 2019-05-03 07:48:02 --> 404 Page Not Found: Uploads/bidang
ERROR - 2019-05-03 07:48:03 --> 404 Page Not Found: Uploads/bidang
ERROR - 2019-05-03 08:43:47 --> 404 Page Not Found: Login/index
