<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-26 04:18:17 --> Severity: Notice --> Undefined variable: ig /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-26 04:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-26 12:45:52 --> Severity: Notice --> Undefined variable: ig /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-05-26 12:45:52 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
