<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 03:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-07 16:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-07 16:27:42 --> 404 Page Not Found: Well-known/assetlinks.json
