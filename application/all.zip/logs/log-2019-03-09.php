<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-09 08:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-09 10:51:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-09 16:40:11 --> 404 Page Not Found: AN_admin/images
ERROR - 2019-03-09 16:40:21 --> 404 Page Not Found: AN_admin/login.php
ERROR - 2019-03-09 16:40:28 --> 404 Page Not Found: Templates/system
ERROR - 2019-03-09 16:40:46 --> 404 Page Not Found: Fckeditor/editor
