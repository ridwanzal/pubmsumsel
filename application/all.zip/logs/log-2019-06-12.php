<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-12 12:50:41 --> Severity: Notice --> Undefined variable: ig /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-06-12 12:50:41 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-06-12 12:51:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /opt/lampp/htdocs/pubmsumsel/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-06-12 12:51:31 --> Unable to connect to the database
ERROR - 2019-06-12 12:53:34 --> Severity: Warning --> file_get_contents(): SSL: Connection reset by peer /opt/lampp/htdocs/pubmsumsel/application/controllers/Home.php 42
ERROR - 2019-06-12 12:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 686
ERROR - 2019-06-12 15:15:10 --> 404 Page Not Found: Animated%20infinite%20fadeInDown%20delay-1s/index
ERROR - 2019-06-12 16:16:41 --> Severity: Error --> Call to undefined function path_adm() /opt/lampp/htdocs/pubmsumsel/application/views/ando/footer.php 239
ERROR - 2019-06-12 16:16:42 --> Severity: Error --> Call to undefined function path_adm() /opt/lampp/htdocs/pubmsumsel/application/views/ando/footer.php 239
ERROR - 2019-06-12 17:30:17 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /opt/lampp/htdocs/pubmsumsel/application/views/ando/home.php 734
