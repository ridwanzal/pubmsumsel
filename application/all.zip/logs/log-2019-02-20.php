<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-20 04:37:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-20 04:37:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-20 04:37:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-20 04:38:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-20 04:38:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-02-20 10:32:40 --> 404 Page Not Found: Robotstxt/index
