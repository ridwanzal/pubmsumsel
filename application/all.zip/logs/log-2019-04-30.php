<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-30 05:07:02 --> 404 Page Not Found: Uploads/bidang
