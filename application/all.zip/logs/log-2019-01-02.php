<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-02 16:17:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-01-02 16:17:04 --> Unable to connect to the database
ERROR - 2019-01-02 16:17:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-01-02 16:18:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:44:42 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:43 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:43 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:43 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:54 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:54 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:44:54 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:45:06 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:45:07 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:45:07 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:45:07 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:48:22 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:48:23 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:48:23 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:48:23 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:50:21 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:50:21 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:50:31 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:51:18 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:51:18 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:51:18 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:53:33 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:55:35 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:55:35 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:55:35 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:55:35 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:55:56 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-01-02 16:56:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/puprmuaraenimkab/public_html/application/controllers/AN_admin.php:1676) /home/puprmuaraenimkab/public_html/system/helpers/url_helper.php 564
ERROR - 2019-01-02 16:56:27 --> 404 Page Not Found: 
ERROR - 2019-01-02 16:56:45 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:57:37 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:57:37 --> 404 Page Not Found: An-component/media
ERROR - 2019-01-02 16:57:37 --> 404 Page Not Found: An-component/media
