<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 19:08:05 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-04 19:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-04 19:08:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-04 19:08:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-04 19:08:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-04 19:08:10 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-04 19:10:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:10:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:10:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:12:41 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:15:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:17:37 --> 404 Page Not Found: AN_admin/pengujian
ERROR - 2020-06-04 19:18:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:18:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:18:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:18:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:18:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:18:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:19:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:20:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:20:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:20:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:21:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:21:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:21:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:22:52 --> 404 Page Not Found: 
ERROR - 2020-06-04 19:22:57 --> 404 Page Not Found: 
ERROR - 2020-06-04 19:23:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:23:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:23:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:25:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:37:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:37:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-04 19:37:58 --> 404 Page Not Found: An-theme/admin
