<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-25 02:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-02-25 02:48:31 --> 404 Page Not Found: Faviconico/index
