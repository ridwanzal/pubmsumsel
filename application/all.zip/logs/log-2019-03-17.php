<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-17 21:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-17 21:12:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-17 21:12:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-17 21:12:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-17 21:12:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-17 23:13:49 --> 404 Page Not Found: Faviconico/index
