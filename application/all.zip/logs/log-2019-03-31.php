<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-31 00:55:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-03-31 05:16:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:16:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:16:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:16:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:16:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:17:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:17:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-31 05:17:30 --> 404 Page Not Found: An-theme/ando
