<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-29 17:19:28 --> Severity: Notice --> unserialize(): Error at offset 186 of 1352 bytes /opt/lampp/htdocs/dpusumsel/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2019-04-29 17:19:28 --> Severity: Warning --> chmod(): Operation not permitted /opt/lampp/htdocs/dpusumsel/system/libraries/Cache/drivers/Cache_file.php 106
