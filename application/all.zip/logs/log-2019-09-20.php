<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-20 18:18:04 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-09-20 18:18:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:18:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:43:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:43:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-20 18:43:30 --> 404 Page Not Found: An-theme/admin
