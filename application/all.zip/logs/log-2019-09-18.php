<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-18 21:08:44 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-09-18 21:08:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:08:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:08:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:08:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:08:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:08:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:09:07 --> Severity: Notice --> unserialize(): Error at offset 4713 of 4851 bytes C:\xampp\htdocs\pubmsumsel\system\libraries\Cache\drivers\Cache_file.php 275
ERROR - 2019-09-18 21:11:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:33 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:11:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:14:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:14:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:14:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:15:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:16:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:16:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:16:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:17:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:18:12 --> 404 Page Not Found: AN_admin/produk_hukum
ERROR - 2019-09-18 21:18:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:18:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:18:15 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:19:40 --> Severity: Compile Error --> Cannot redeclare AN_admin::data_infastruktur() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 608
ERROR - 2019-09-18 21:19:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:19:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:19:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:20:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Struktur_organisasi C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 348
ERROR - 2019-09-18 21:20:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Struktur_organisasi C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 348
ERROR - 2019-09-18 21:20:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Struktur_organisasi C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 348
ERROR - 2019-09-18 21:20:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Struktur_organisasi C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 348
ERROR - 2019-09-18 21:20:50 --> Severity: error --> Exception: Call to undefined method Struktur_o::get_struktur_organisasi() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 627
ERROR - 2019-09-18 21:21:25 --> Severity: error --> Exception: Call to undefined method Struktur_o::get_struktur_organisasi() C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 627
ERROR - 2019-09-18 21:21:40 --> Severity: Notice --> Undefined variable: get_infrastruktur C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:21:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:21:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:21:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:21:57 --> Severity: Notice --> Undefined variable: get_infrastruktur C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:21:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:21:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:21:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:13 --> Severity: Notice --> Undefined variable: get_infrastruktur C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\admin\data_infastruktur.php 79
ERROR - 2019-09-18 21:22:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:38 --> Severity: Notice --> Undefined variable: get_infrastruktur C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 79
ERROR - 2019-09-18 21:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 79
ERROR - 2019-09-18 21:22:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:52 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:53 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'no_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'nama_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'panjang_ruas' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:22:54 --> Severity: Notice --> Trying to get property 'id_infrastruktur' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:22:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:22:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:23:18 --> Severity: error --> Exception: syntax error, unexpected 'organisasi' (T_STRING), expecting :: (T_PAAMAYIM_NEKUDOTAYIM) C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 79
ERROR - 2019-09-18 21:23:29 --> Severity: error --> Exception: syntax error, unexpected 'organisasi' (T_STRING), expecting :: (T_PAAMAYIM_NEKUDOTAYIM) C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 79
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:45 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:46 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 81
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_nip' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 82
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'jabatan_nama' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 83
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 85
ERROR - 2019-09-18 21:24:47 --> Severity: Notice --> Trying to get property 'so_id' of non-object C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 86
ERROR - 2019-09-18 21:24:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:24:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:24:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:25:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:26:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:26:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:27:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:28:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:29:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:18 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:30:22 --> 404 Page Not Found: AN_admin/edit_data_struktur%20organisasi
ERROR - 2019-09-18 21:32:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:32:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:32:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:33:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:33:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:33:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:34:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:34:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\pubmsumsel\application\views\admin\struktur_organisasi.php 37
ERROR - 2019-09-18 21:36:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:39 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:36:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:39:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:39:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:39:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:42:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:43:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:43:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:43:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:45:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:47:50 --> Severity: error --> Exception: syntax error, unexpected '{', expecting '(' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 610
ERROR - 2019-09-18 21:48:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:48:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:49:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:56:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:57:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:57:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 21:57:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:01:16 --> Severity: error --> Exception: syntax error, unexpected ''jabatan_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 640
ERROR - 2019-09-18 22:01:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:01:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:01:23 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:02:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:03:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-09-18 22:04:14 --> 404 Page Not Found: An-theme/admin
