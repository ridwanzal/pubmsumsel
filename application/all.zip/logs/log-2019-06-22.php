<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-22 12:53:49 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
ERROR - 2019-06-22 13:02:09 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 310
