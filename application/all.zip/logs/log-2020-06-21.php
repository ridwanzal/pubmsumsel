<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-21 17:33:04 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-21 17:33:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:33:09 --> 404 Page Not Found: An-component/media
ERROR - 2020-06-21 17:43:39 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:46:45 --> Severity: Notice --> Undefined property: Pengujian::$pengujian C:\xampp\htdocs\pubmsumsel\application\controllers\Pengujian.php 24
ERROR - 2020-06-21 17:46:45 --> Severity: error --> Exception: Call to a member function get_data() on null C:\xampp\htdocs\pubmsumsel\application\controllers\Pengujian.php 24
ERROR - 2020-06-21 17:46:52 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:47:58 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:49:50 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:50:14 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:54:01 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:54:18 --> Severity: error --> Exception: Class Pengujian already exists and doesn't extend CI_Model C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 353
ERROR - 2020-06-21 17:54:31 --> Severity: Notice --> Undefined property: Pengujian::$pengujian C:\xampp\htdocs\pubmsumsel\application\controllers\Pengujian.php 23
ERROR - 2020-06-21 17:54:31 --> Severity: error --> Exception: Call to a member function get_data() on null C:\xampp\htdocs\pubmsumsel\application\controllers\Pengujian.php 23
ERROR - 2020-06-21 18:49:16 --> 404 Page Not Found: Account/index
ERROR - 2020-06-21 18:49:18 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-06-21 18:49:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:49:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:49:24 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:49:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Pengujian C:\xampp\htdocs\pubmsumsel\system\core\Loader.php 348
ERROR - 2020-06-21 18:49:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:49:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:49:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:50:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:50:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:50:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:50:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 18:51:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:06:41 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 50
ERROR - 2020-06-21 19:06:59 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 56
ERROR - 2020-06-21 19:07:11 --> Severity: error --> Exception: syntax error, unexpected '$value' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 50
ERROR - 2020-06-21 19:07:29 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 50
ERROR - 2020-06-21 19:07:35 --> Severity: error --> Exception: syntax error, unexpected '"' C:\xampp\htdocs\pubmsumsel\application\views\admin\pengujian.php 50
ERROR - 2020-06-21 19:08:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:46 --> 404 Page Not Found: An_admin/download_fileinventory.png
ERROR - 2020-06-21 19:08:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:08:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:09:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:09:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:09:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:12:58 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:14:12 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:14:21 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:14:41 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:15:00 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1403
ERROR - 2020-06-21 19:15:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:15:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:15:06 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:15:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1391
ERROR - 2020-06-21 19:15:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1391
ERROR - 2020-06-21 19:16:24 --> Severity: error --> Exception: syntax error, unexpected '$user' (T_VARIABLE), expecting ')' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:16:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:17:10 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1402
ERROR - 2020-06-21 19:19:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php:1404) C:\xampp\htdocs\pubmsumsel\system\helpers\url_helper.php 564
ERROR - 2020-06-21 19:19:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:19:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:19:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:24:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:24:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:24:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:35:02 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\pubmsumsel\application\controllers\AN_admin.php 1391
ERROR - 2020-06-21 19:35:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:35:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-06-21 19:35:58 --> 404 Page Not Found: An-theme/admin
