<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-06 00:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-06 08:02:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-06 08:02:37 --> 404 Page Not Found: Faviconico/index
