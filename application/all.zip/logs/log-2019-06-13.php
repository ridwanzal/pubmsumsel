<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-13 04:02:46 --> 404 Page Not Found: Wow%20fadeIn%20delay-1s/index
