<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-28 12:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-28 12:39:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-28 12:39:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-28 12:39:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-03-28 19:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-03-28 19:55:14 --> 404 Page Not Found: Well-known/assetlinks.json
