<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-23 18:07:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-05-23 18:07:17 --> Unable to connect to the database
ERROR - 2019-05-23 18:07:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\pubmsumsel\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-05-23 18:07:18 --> Unable to connect to the database
ERROR - 2019-05-23 18:07:56 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 42
ERROR - 2019-05-23 18:07:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 686
ERROR - 2019-05-23 18:08:36 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 42
ERROR - 2019-05-23 18:08:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 686
ERROR - 2019-05-23 18:17:47 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 42
ERROR - 2019-05-23 18:17:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 686
ERROR - 2019-05-23 18:34:09 --> 404 Page Not Found: An-component/media
ERROR - 2019-05-23 18:34:27 --> 404 Page Not Found: An-component/media
ERROR - 2019-05-23 18:46:32 --> 404 Page Not Found: Page/an-component
ERROR - 2019-05-23 18:46:37 --> 404 Page Not Found: Page/an-component
ERROR - 2019-05-23 18:46:50 --> 404 Page Not Found: Page/an-component
ERROR - 2019-05-23 18:46:59 --> 404 Page Not Found: Page/an-component
ERROR - 2019-05-23 18:49:06 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 244
ERROR - 2019-05-23 19:49:55 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-05-23 19:49:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:16 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:50:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-05-23 19:51:01 --> 404 Page Not Found: An-theme/admin
