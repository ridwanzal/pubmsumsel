<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-05 11:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-05 14:09:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-05 14:09:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-05 14:09:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-04-05 14:09:32 --> 404 Page Not Found: Faviconico/index
