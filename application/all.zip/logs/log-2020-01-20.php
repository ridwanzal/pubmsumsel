<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-20 16:02:46 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:02:51 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-01-20 16:02:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:02:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:03:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:03:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:03:17 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:03:25 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:03:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:04:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:01 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:04:29 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:26:16 --> Severity: Notice --> Undefined index: so_nama C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 117
ERROR - 2020-01-20 16:27:01 --> Severity: Notice --> Undefined index: so_jabatan_nama C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 118
ERROR - 2020-01-20 16:46:12 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:46:15 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:47 --> Severity: error --> Exception: syntax error, unexpected '4' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:48:52 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\pubmsumsel\application\views\ando\struktur_organisasi.php 108
ERROR - 2020-01-20 16:52:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:22 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:36 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:47 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:52:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:53:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:14 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:32 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:34 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:35 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:37 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:45 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-01-20 16:54:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-01-20 16:54:57 --> 404 Page Not Found: An-theme/admin
