<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-24 11:00:04 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-06-24 11:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 819
ERROR - 2019-06-24 11:00:07 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-06-24 11:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 819
ERROR - 2019-06-24 11:00:56 --> Severity: Warning --> file_get_contents(https://api.instagram.com/v1/users/self/media/recent/?access_token=12097245702.1677ed0.a50372125dee4a0490dd1036e238fd79&amp;count=6): failed to open stream: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\pubmsumsel\application\controllers\Home.php 45
ERROR - 2019-06-24 11:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 819
ERROR - 2019-06-24 20:02:56 --> 404 Page Not Found: Img/pu.png
ERROR - 2019-06-24 20:02:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:02:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:02:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:03:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:04:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:04:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:04:13 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:05:52 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:06:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:06:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2019-06-24 20:06:48 --> 404 Page Not Found: An-theme/admin
