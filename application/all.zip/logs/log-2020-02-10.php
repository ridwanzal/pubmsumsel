<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-10 10:17:23 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-10 10:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-10 10:23:58 --> 404 Page Not Found: Login/index
ERROR - 2020-02-10 10:24:01 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-02-10 10:36:07 --> Severity: Notice --> Undefined variable: ig C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-10 10:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\pubmsumsel\application\views\ando\home.php 2157
ERROR - 2020-02-10 11:48:16 --> 404 Page Not Found: Img/pu.png
ERROR - 2020-02-10 11:48:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:19 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:27 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:48:50 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2020-02-10 11:51:12 --> 404 Page Not Found: An-theme/admin
