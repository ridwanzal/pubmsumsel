<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-02 16:53:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /opt/lampp/htdocs/pubmsumsel/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-05-02 16:53:04 --> Unable to connect to the database
ERROR - 2019-05-02 16:53:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /opt/lampp/htdocs/pubmsumsel/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-05-02 16:53:25 --> Unable to connect to the database
