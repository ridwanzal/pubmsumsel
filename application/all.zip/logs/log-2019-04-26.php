<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:15 --> Severity: Notice --> Use of undefined constant aka - assumed 'aka' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:20 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:23:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 179
ERROR - 2019-04-26 00:37:18 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 00:37:25 --> Severity: Parsing Error --> syntax error, unexpected '"', expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 00:37:48 --> Severity: Parsing Error --> syntax error, unexpected '$aka' (T_VARIABLE), expecting ',' or ';' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 00:38:28 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 00:38:36 --> Severity: Parsing Error --> syntax error, unexpected '$aka' (T_VARIABLE), expecting ',' or ';' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 00:38:56 --> Severity: Parsing Error --> syntax error, unexpected '"', expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 177
ERROR - 2019-04-26 04:45:46 --> 404 Page Not Found: Login/index
ERROR - 2019-04-26 04:45:49 --> 404 Page Not Found: Masuk/index
ERROR - 2019-04-26 05:34:40 --> Severity: Notice --> Undefined offset: 0 /opt/lampp/htdocs/dpunew/application/views/ando/home.php 165
ERROR - 2019-04-26 05:34:40 --> Severity: Notice --> Undefined offset: 0 /opt/lampp/htdocs/dpunew/application/views/ando/home.php 165
ERROR - 2019-04-26 05:34:40 --> Severity: Notice --> Undefined offset: 0 /opt/lampp/htdocs/dpunew/application/views/ando/home.php 165
ERROR - 2019-04-26 05:34:40 --> Severity: Notice --> Undefined offset: 0 /opt/lampp/htdocs/dpunew/application/views/ando/home.php 165
ERROR - 2019-04-26 05:34:40 --> Severity: Notice --> Undefined offset: 0 /opt/lampp/htdocs/dpunew/application/views/ando/home.php 165
ERROR - 2019-04-26 05:36:42 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ';' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 166
ERROR - 2019-04-26 05:36:49 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 166
ERROR - 2019-04-26 05:36:55 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 166
ERROR - 2019-04-26 05:37:35 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:38:02 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:39:03 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:39:08 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:39:17 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:39:24 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:04 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:10 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:11 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:12 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:19 --> Severity: Notice --> Undefined variable: artikel_pengumuma /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:22 --> Severity: Notice --> Undefined variable: artikel_pengumuma /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:40:49 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:41:06 --> Severity: Notice --> Use of undefined constant id - assumed 'id' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:41:25 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:41:36 --> Severity: Parsing Error --> syntax error, unexpected '>' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:41:42 --> Severity: Parsing Error --> syntax error, unexpected '>' /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
ERROR - 2019-04-26 05:42:07 --> Severity: Notice --> Trying to get property of non-object /opt/lampp/htdocs/dpunew/application/views/ando/home.php 156
