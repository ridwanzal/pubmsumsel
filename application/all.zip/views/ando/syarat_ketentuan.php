<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

	<div class='col-md-12' id="header-page">
			<h1><span>Syarat Dan Ketentuan</span></h1>
	</div>

		<div class='col-md-8 left-side'>

			<div class="artikel">
				<div class="konten">
					<?php echo reversequote($informasi["terms_conditions"],'all'); ?>
					
				</div>
			</div>

		</div>