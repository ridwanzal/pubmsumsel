<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

	<div class='col-md-12' id="header-page">
			<h1><span><?php echo $download['nama_file']; ?></span></h1>
	</div>

		<div class='col-md-8 left-side'>

			<div class="artikel">
				<div class="konten">
							Buat sendiri kontennya disini		
				</div>
			</div>

		</div>